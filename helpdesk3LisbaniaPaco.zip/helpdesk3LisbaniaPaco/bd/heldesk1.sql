-- =====================================================================
-- Base de datos del Sistema HelpDesk (proyecto NetBeans helpdesk3LisbaniaPaco)
-- Importar en phpMyAdmin > Importar (XAMPP: MySQL en localhost:3306, root sin clave).
-- ATENCIÓN: borra y vuelve a crear las 7 tablas de heldesk1, con datos de ejemplo.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS heldesk1 CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE heldesk1;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS incidencia;
DROP TABLE IF EXISTS tecnico;
DROP TABLE IF EXISTS usuario;
DROP TABLE IF EXISTS login;
DROP TABLE IF EXISTS estado;
DROP TABLE IF EXISTS especialidad;
DROP TABLE IF EXISTS categoria;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE categoria (
  id_categoria INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(200) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE especialidad (
  id_especialidad INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(200) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE estado (
  id_estado INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE usuario (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombres VARCHAR(80) NOT NULL,
  apellidos VARCHAR(80) NOT NULL,
  correo VARCHAR(100) NULL,
  telefono VARCHAR(20) NULL,
  cargo VARCHAR(80) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE tecnico (
  id_tecnico INT AUTO_INCREMENT PRIMARY KEY,
  nombres VARCHAR(80) NOT NULL,
  apellidos VARCHAR(80) NOT NULL,
  correo VARCHAR(100) NULL,
  telefono VARCHAR(20) NULL,
  especialidad_id INT NULL,
  turno VARCHAR(20) NULL,
  CONSTRAINT fk_tecnico_especialidad FOREIGN KEY (especialidad_id) REFERENCES especialidad(id_especialidad)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE incidencia (
  id_incidencia INT AUTO_INCREMENT PRIMARY KEY,
  ticket VARCHAR(20) NOT NULL UNIQUE,
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  titulo VARCHAR(150) NOT NULL,
  descripcion VARCHAR(300) NULL,
  prioridad VARCHAR(20) NOT NULL,
  usuario_id INT NOT NULL,
  tecnico_id INT NULL,
  categoria_id INT NOT NULL,
  estado_id INT NOT NULL,
  CONSTRAINT fk_inc_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id_usuario),
  CONSTRAINT fk_inc_tecnico FOREIGN KEY (tecnico_id) REFERENCES tecnico(id_tecnico),
  CONSTRAINT fk_inc_categoria FOREIGN KEY (categoria_id) REFERENCES categoria(id_categoria),
  CONSTRAINT fk_inc_estado FOREIGN KEY (estado_id) REFERENCES estado(id_estado)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE login (
  id_login INT AUTO_INCREMENT PRIMARY KEY,
  usuario VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL,
  rol VARCHAR(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------- Datos de ejemplo ----------------------
INSERT INTO categoria (nombre, descripcion) VALUES
('Hardware', 'Fallas de equipos físicos'),
('Software Hospitalario', 'Aplicaciones del hospital'),
('Red', 'Conectividad y cableado'),
('Impresoras', 'Impresoras y escáneres'),
('Correo Institucional', 'Cuentas de correo'),
('Base de Datos', 'Servidores y respaldos'),
('Equipos Biomédicos', 'Equipos médicos con software'),
('Sistema HIS', 'Sistema de información hospitalaria');

INSERT INTO especialidad (nombre, descripcion) VALUES
('Redes', 'Redes y comunicaciones'),
('Hardware', 'Mantenimiento de equipos'),
('Software', 'Instalación y soporte de software'),
('Bases de Datos', 'Administración de bases de datos'),
('Impresoras', 'Soporte de impresión'),
('Equipos Biomédicos', 'Soporte a equipos biomédicos');

INSERT INTO estado (nombre) VALUES ('Pendiente'), ('Asignada'), ('En Proceso'), ('Resuelta');

INSERT INTO usuario (nombres, apellidos, correo, telefono, cargo) VALUES
('María', 'Quispe Mamani', 'maria.quispe@hospital.bo', '70111111', 'Enfermera'),
('Juan', 'Condori Flores', 'juan.condori@hospital.bo', '70222222', 'Médico'),
('Rosa', 'Mamani Choque', 'rosa.mamani@hospital.bo', '70333333', 'Recepcionista'),
('Carlos', 'Huanca Apaza', 'carlos.huanca@hospital.bo', '70444444', 'Laboratorista'),
('Elena', 'Vargas Rojas', 'elena.vargas@hospital.bo', '70555555', 'Administradora'),
('Pedro', 'Colque Ticona', 'pedro.colque@hospital.bo', '70666666', 'Farmacéutico');

INSERT INTO tecnico (nombres, apellidos, correo, telefono, especialidad_id, turno) VALUES
('Luis', 'Choque Mamani', 'luis.choque@hospital.bo', '71111111', 1, 'Mañana'),
('Ana', 'Flores Quispe', 'ana.flores@hospital.bo', '71222222', 2, 'Tarde'),
('Diego', 'Apaza Condori', 'diego.apaza@hospital.bo', '71333333', 3, 'Mañana'),
('Sofía', 'Ticona Vargas', 'sofia.ticona@hospital.bo', '71444444', 4, 'Noche'),
('Marco', 'Rojas Huanca', 'marco.rojas@hospital.bo', '71555555', 6, 'Tarde');

INSERT INTO incidencia (ticket, fecha, hora, titulo, descripcion, prioridad, usuario_id, tecnico_id, categoria_id, estado_id) VALUES
('INC-0001', '2026-10-01', '08:15:00', 'PC de recepción no enciende', 'No da imagen al encender', 'Alta', 3, 2, 1, 3),
('INC-0002', '2026-10-01', '09:30:00', 'Sin internet en consultorio 3', 'Cable de red dañado', 'Media', 2, 1, 3, 2),
('INC-0003', '2026-10-02', '10:05:00', 'Impresora atascada', 'Papel atascado en bandeja', 'Baja', 1, NULL, 4, 1),
('INC-0004', '2026-10-02', '11:20:00', 'Error en sistema HIS', 'No guarda historias clínicas', 'Crítica', 5, 3, 8, 3),
('INC-0005', '2026-10-03', '14:00:00', 'Correo institucional bloqueado', 'No puede iniciar sesión', 'Media', 4, 3, 5, 4),
('INC-0006', '2026-10-03', '15:45:00', 'Respaldo de base de datos falló', 'Backup nocturno incompleto', 'Alta', 5, 4, 6, 2),
('INC-0007', '2026-10-04', '08:50:00', 'Monitor de signos vitales sin software', 'Falla de comunicación', 'Crítica', 2, 5, 7, 3),
('INC-0008', '2026-10-05', '09:10:00', 'Lentitud en software hospitalario', 'Responde muy lento', 'Media', 6, NULL, 2, 1),
('INC-0009', '2026-10-06', '13:25:00', 'Teclado defectuoso', 'Varias teclas no responden', 'Baja', 1, 2, 1, 4),
('INC-0010', '2026-10-07', '16:40:00', 'Impresora de laboratorio sin tinta', 'Requiere cambio de cartucho', 'Baja', 4, NULL, 4, 1);

INSERT INTO login (usuario, password, rol) VALUES
('admin', 'admin123', 'Administrador'),
('lisbania', '1234', 'Administrador'),
('luis', '1234', 'Técnico'),
('ana', '1234', 'Técnico'),
('diego', '1234', 'Técnico'),
('invitado', '1234', 'Usuario');
